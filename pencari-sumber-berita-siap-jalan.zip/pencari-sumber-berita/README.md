# Pencari Sumber Berita — Web App

Aplikasi lokal untuk menelusuri kemungkinan sumber berita dari gambar/screenshot teks.

## Fitur
- Upload gambar JPG/JPEG/PNG/WEBP dengan validasi ukuran dan tipe.
- OCR gambar menggunakan RapidOCR.
- Preprocessing teks dan ekstraksi kata kunci TF-IDF.
- Penelusuran kandidat artikel via Google News RSS.
- Ekstraksi teks artikel yang dapat diakses dan pemeringkatan dengan TF-IDF + Cosine Similarity.
- Hasil menampilkan teks OCR, kata kunci, skor kemiripan, judul, dan tautan.
- Loading, error handling, hasil kosong, dan batas hasil.
- Tidak menyatakan kandidat dengan skor tertinggi sebagai sumber asli atau menyatakan berita benar.

## Prasyarat
- Python 3.10 atau lebih baru (disarankan Python 3.11/3.12).
- Node.js 20.19+ atau 22.12+ dan npm.
- Internet untuk mencari artikel kandidat dan mengambil isi halaman.
- Pertama kali menjalankan OCR mungkin memerlukan unduhan model/dependensi dan waktu lebih lama.

## Cara menjalankan di Windows

### 1. Backend
Buka terminal di folder proyek:

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Jika PowerShell memblokir aktivasi virtual environment, jalankan perintah ini pada terminal yang sama lalu ulangi aktivasi:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Dokumentasi API: http://127.0.0.1:8000/docs

### 2. Frontend
Buka terminal kedua, dari folder utama proyek:

```powershell
cd frontend
npm install
npm run dev
```

Buka alamat yang muncul di terminal, biasanya http://localhost:5173.

## Cara menjalankan di macOS/Linux

Terminal 1:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Terminal 2:
```bash
cd frontend
npm install
npm run dev
```

## Alur kerja teknis
1. Frontend mengirim gambar ke `POST /api/search-source`.
2. Backend memvalidasi ukuran dan format gambar.
3. RapidOCR mengekstrak teks dan confidence OCR.
4. Teks dibersihkan untuk mengurangi noise; TF-IDF dipakai untuk memilih kata kunci.
5. Kata kunci digunakan untuk mencari kandidat artikel melalui Google News RSS.
6. Backend mencoba mengambil teks artikel yang dapat diakses.
7. TF-IDF dan cosine similarity menghitung kemiripan teks OCR terhadap isi kandidat. Bila isi artikel tidak bisa diambil, kandidat dapat dinilai dari judul/deskripsi yang tersedia dan ditandai demikian.
8. Frontend menampilkan ranking dan tautan untuk verifikasi manual.

## Batasan yang perlu diketahui
- Google News RSS, situs berita, dan jaringan dapat membatasi akses, mengubah format, atau memblokir permintaan. Hasil pencarian tidak dijamin selalu tersedia.
- Tidak semua halaman berita dapat diekstrak karena paywall, anti-bot, JavaScript, atau robots policy.
- Skor cosine similarity adalah ukuran kemiripan teks, bukan probabilitas kebenaran dan bukan bukti bahwa suatu halaman merupakan sumber asli.
- Tidak ada pelatihan model supervised di aplikasi ini. RapidOCR digunakan sebagai model pra-latih; TF-IDF dan cosine similarity adalah metode pemrosesan/pemeringkatan teks.
- Evaluasi performa model tidak diklaim telah dilakukan. Untuk evaluasi akademik, siapkan dataset uji berlabel dan hitung metrik seperti OCR character/word error rate serta Precision@k/MRR untuk ranking.
- Gunakan hanya untuk keperluan riset/pembelajaran dan hormati ketentuan situs yang diakses.

## Troubleshooting
- `npm` tidak dikenali: pasang Node.js LTS lalu buka terminal baru.
- `py` tidak dikenali: pasang Python dan aktifkan opsi Add Python to PATH; coba `python`.
- OCR pertama kali lambat: tunggu proses unduh/pemuatan model.
- Backend tidak terhubung: pastikan terminal backend masih berjalan pada port 8000.
- Hasil kosong: coba gambar lebih jelas dengan teks yang terbaca dan koneksi internet aktif.
