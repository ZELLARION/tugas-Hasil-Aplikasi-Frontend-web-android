from __future__ import annotations

import io
import ipaddress
import logging
import re
import socket
import time
from urllib.parse import quote_plus, urlparse

import numpy as np
import requests
import trafilatura
from bs4 import BeautifulSoup
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("telusur")

APP_TITLE = "Telusur API"
MAX_IMAGE_BYTES = 8 * 1024 * 1024
ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
REQUEST_TIMEOUT = (5, 12)
MAX_CANDIDATES = 8

app = FastAPI(
    title=APP_TITLE,
    description="API penelusuran kandidat sumber berita dari gambar dengan OCR, TF-IDF, dan cosine similarity.",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

_ocr_engine = None


@app.get("/")
def root():
    return {
        "name": APP_TITLE,
        "status": "ok",
        "docs": "/docs",
        "pipeline": ["RapidOCR", "preprocessing", "TF-IDF keywords", "Google News RSS", "TF-IDF + cosine similarity"],
    }


@app.get("/health")
def health():
    return {"status": "ok", "ocr_initialized": _ocr_engine is not None}


def clean_text(text: str) -> str:
    text = (text or "").replace("\x00", " ")
    text = re.sub(r"https?://\S+", " ", text, flags=re.I)
    text = re.sub(r"[^\w\s.,:;!?%/-]", " ", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def get_ocr_engine():
    global _ocr_engine
    if _ocr_engine is None:
        try:
            from rapidocr import RapidOCR
            _ocr_engine = RapidOCR()
        except Exception as exc:
            logger.exception("Gagal memuat RapidOCR")
            raise HTTPException(
                status_code=503,
                detail="RapidOCR belum dapat dimuat. Pastikan dependensi terpasang dan coba lagi. Detail: " + str(exc)[:220],
            )
    return _ocr_engine


def run_ocr(image: Image.Image) -> tuple[str, float]:
    engine = get_ocr_engine()
    # RapidOCR accepts numpy arrays; RGB image is converted to an array.
    arr = np.array(image.convert("RGB"))
    try:
        output = engine(arr)
        texts = getattr(output, "txts", None) or []
        scores = getattr(output, "scores", None) or []
        text = "\n".join(str(t) for t in texts if t and str(t).strip())
        valid_scores = []
        for score in scores:
            try:
                valid_scores.append(float(score))
            except (TypeError, ValueError):
                pass
        confidence = float(sum(valid_scores) / len(valid_scores)) if valid_scores else None
        return text.strip(), confidence
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("OCR gagal")
        raise HTTPException(status_code=422, detail=f"Gagal membaca teks dari gambar: {str(exc)[:200]}")


def extract_keywords(text: str, limit: int = 12) -> list[dict]:
    cleaned = clean_text(text)
    if not cleaned:
        return []
    try:
        vectorizer = TfidfVectorizer(
            lowercase=True,
            token_pattern=r"(?u)\b[a-zA-ZÀ-ÿ0-9][a-zA-ZÀ-ÿ0-9_-]{2,}\b",
            stop_words=None,
            max_features=2500,
            ngram_range=(1, 2),
        )
        matrix = vectorizer.fit_transform([cleaned])
        terms = vectorizer.get_feature_names_out()
        values = matrix.toarray()[0]
        order = values.argsort()[::-1]
        return [
            {"term": str(terms[i]), "score": round(float(values[i]), 6)}
            for i in order[:limit] if values[i] > 0
        ]
    except ValueError:
        return []


def public_http_url(url: str) -> bool:
    # Basic SSRF guard for links returned by the external search provider.
    try:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            return False
        host = parsed.hostname.lower()
        if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
            return False
        # Avoid literal private/reserved IPs. DNS is not revalidated at connect time;
        # this is defense-in-depth, not a hardened proxy boundary.
        try:
            ip = ipaddress.ip_address(host)
            if not ip.is_global:
                return False
        except ValueError:
            pass
        return True
    except Exception:
        return False


def google_news_search(query: str, max_items: int = MAX_CANDIDATES) -> list[dict]:
    query = clean_text(query)[:350]
    if len(query) < 3:
        return []
    url = "https://news.google.com/rss/search?q=" + quote_plus(query) + "&hl=id&gl=ID&ceid=ID:id"
    headers = {"User-Agent": "TelusurResearchPrototype/1.0 (educational research)"}
    try:
        response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "xml")
        items = []
        seen = set()
        for item in soup.find_all("item")[: max_items * 2]:
            title = item.title.get_text(" ", strip=True) if item.title else ""
            link = item.link.get_text(strip=True) if item.link else ""
            description = item.description.get_text(" ", strip=True) if item.description else ""
            if not title or not link or link in seen or not public_http_url(link):
                continue
            seen.add(link)
            # RSS description often contains markup. Strip it before returning to the UI.
            snippet = BeautifulSoup(description, "html.parser").get_text(" ", strip=True)
            items.append({
                "title": title,
                "url": link,
                "snippet": snippet[:600],
                "domain": urlparse(link).hostname or "",
                "article_text": "",
                "content_extracted": False,
            })
            if len(items) >= max_items:
                break
        return items
    except Exception as exc:
        logger.warning("Pencarian RSS gagal: %s", exc)
        return []


def fetch_article_text(url: str) -> str:
    if not public_http_url(url):
        return ""
    headers = {"User-Agent": "Mozilla/5.0 (compatible; TelusurResearchPrototype/1.0)"}
    try:
        response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True, stream=True)
        # Reject non-web redirects and obvious local destination after redirect.
        if not public_http_url(response.url):
            response.close()
            return ""
        content_type = response.headers.get("content-type", "").lower()
        if "text/html" not in content_type and "application/xhtml" not in content_type:
            response.close()
            return ""
        body = response.raw.read(1_500_000, decode_content=True)
        response.close()
        extracted = trafilatura.extract(body, url=response.url, include_comments=False, include_tables=False)
        return clean_text(extracted or "")[:30000]
    except Exception as exc:
        logger.debug("Artikel tidak dapat diekstrak (%s): %s", url, exc)
        return ""


def score_candidates(ocr_text: str, candidates: list[dict]) -> list[dict]:
    if not candidates:
        return []
    docs = [clean_text(ocr_text)]
    docs.extend(clean_text(c.get("article_text") or (c.get("title", "") + " " + c.get("snippet", ""))) for c in candidates)
    try:
        vectorizer = TfidfVectorizer(
            lowercase=True,
            token_pattern=r"(?u)\b[a-zA-ZÀ-ÿ0-9][a-zA-ZÀ-ÿ0-9_-]{2,}\b",
            ngram_range=(1, 2),
            max_features=12000,
        )
        matrix = vectorizer.fit_transform(docs)
        scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()
    except ValueError:
        scores = np.zeros(len(candidates))
    for candidate, score in zip(candidates, scores):
        candidate["similarity"] = round(float(score), 6)
        candidate.pop("article_text", None)
    return sorted(candidates, key=lambda c: c["similarity"], reverse=True)


@app.post("/api/search-source")
async def search_source(file: UploadFile = File(...)):
    if file.content_type not in ALLOWED_MIME:
        raise HTTPException(status_code=415, detail="Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.")
    content = await file.read(MAX_IMAGE_BYTES + 1)
    if not content:
        raise HTTPException(status_code=400, detail="File gambar kosong.")
    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="Ukuran gambar melebihi batas 8 MB.")
    try:
        image = Image.open(io.BytesIO(content))
        image.verify()
        image = Image.open(io.BytesIO(content))
        if image.width > 8000 or image.height > 8000:
            raise HTTPException(status_code=413, detail="Resolusi gambar terlalu besar. Maksimal 8000 × 8000 piksel.")
        image.load()
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(status_code=400, detail="File bukan gambar valid atau gambarnya rusak.")

    start = time.perf_counter()
    ocr_text, confidence = run_ocr(image)
    if len(ocr_text) > 20000:
        ocr_text = ocr_text[:20000]
    keywords = extract_keywords(ocr_text)
    if len(clean_text(ocr_text)) < 12:
        return {
            "status": "empty_ocr",
            "message": "Teks yang terbaca terlalu sedikit untuk menelusuri artikel. Coba gambar yang lebih tajam dan memuat teks lebih banyak.",
            "ocr_text": ocr_text,
            "ocr_confidence": confidence,
            "keywords": keywords,
            "candidates": [],
            "processing_seconds": round(time.perf_counter() - start, 3),
        }

    # Search with informative keyword terms first; use OCR excerpt as a fallback.
    query = " ".join(k["term"] for k in keywords[:8]) or clean_text(ocr_text)[:250]
    candidates = google_news_search(query)
    if not candidates:
        # A shorter excerpt can work better if keyword phrases yield no results.
        excerpt = clean_text(ocr_text)[:220]
        candidates = google_news_search(excerpt) if excerpt and excerpt != query else []

    for candidate in candidates:
        candidate["article_text"] = fetch_article_text(candidate["url"])
        candidate["content_extracted"] = bool(candidate["article_text"])
    candidates = score_candidates(ocr_text, candidates)

    return {
        "status": "ok" if candidates else "no_candidates",
        "message": (
            "Kandidat diurutkan berdasarkan kemiripan teks. Verifikasi manual diperlukan."
            if candidates else
            "Teks OCR berhasil diproses, tetapi tidak ada kandidat yang tersedia. Periksa koneksi internet atau coba gambar lain."
        ),
        "ocr_text": ocr_text,
        "ocr_confidence": confidence,
        "keywords": keywords,
        "candidates": candidates,
        "processing_seconds": round(time.perf_counter() - start, 3),
    }
