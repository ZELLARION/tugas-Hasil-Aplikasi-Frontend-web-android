# Checklist sebelum dikumpulkan

- [ ] Frontend berhasil dibuka dari `npm run dev`.
- [ ] Backend berhasil dijalankan dari `uvicorn app.main:app --reload`.
- [ ] Endpoint `/health` merespons `{"status":"ok", ...}`.
- [ ] Uji unggah gambar berita yang jelas dan catat hasil OCR.
- [ ] Uji file non-gambar (contoh TXT) untuk membuktikan validasi format.
- [ ] Uji gambar kosong/teks tidak terbaca untuk melihat empty state.
- [ ] Uji saat backend dimatikan untuk mengambil screenshot error handling.
- [ ] Ambil screenshot halaman utama, upload/preview, loading, hasil, error, dan empty state.
- [ ] Jangan tulis bahwa akurasi model sudah dievaluasi jika belum melakukan pengujian berlabel.
- [ ] Catat bahwa sumber artikel memerlukan internet dan sebagian situs dapat membatasi scraping.
