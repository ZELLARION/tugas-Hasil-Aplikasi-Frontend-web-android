import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight, BadgeCheck, BookOpen, Check, ChevronRight, CircleAlert,
  Clock3, FileImage, FileSearch, Globe2, ImagePlus, Info, LoaderCircle,
  Newspaper, RotateCcw, Search, ShieldCheck, Sparkles, UploadCloud, X
} from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';
const MAX_BYTES = 8 * 1024 * 1024;
const ACCEPT = ['image/jpeg', 'image/png', 'image/webp'];

function App() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('results');
  const [health, setHealth] = useState('checking');
  const inputRef = useRef(null);

  useEffect(() => {
    fetch(`${API_BASE}/health`).then(r => r.ok ? r.json() : Promise.reject())
      .then(() => setHealth('online')).catch(() => setHealth('offline'));
  }, []);

  useEffect(() => {
    if (!file) { setPreview(''); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  function validateAndSet(selected) {
    setError('');
    setResult(null);
    if (!selected) return;
    if (!ACCEPT.includes(selected.type)) {
      setFile(null);
      setError('Format belum didukung. Gunakan gambar JPG, PNG, atau WEBP.');
      return;
    }
    if (selected.size > MAX_BYTES) {
      setFile(null);
      setError('Ukuran gambar melebihi 8 MB. Kompres gambar lalu coba lagi.');
      return;
    }
    setFile(selected);
  }

  function reset() {
    setFile(null); setResult(null); setError(''); setLoading(false);
    setActiveTab('results');
    if (inputRef.current) inputRef.current.value = '';
  }

  async function runSearch() {
    if (!file || loading) return;
    setLoading(true); setError(''); setResult(null);
    try {
      const form = new FormData();
      form.append('file', file);
      const response = await fetch(`${API_BASE}/api/search-source`, { method: 'POST', body: form });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.detail || 'Pencarian gagal. Periksa backend dan coba lagi.');
      setResult(data);
      setActiveTab(data.candidates?.length ? 'results' : 'ocr');
    } catch (e) {
      setError(e.message || 'Tidak dapat terhubung ke backend. Pastikan server FastAPI berjalan di port 8000.');
    } finally {
      setLoading(false);
    }
  }

  const candidates = result?.candidates || [];

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="Telusur beranda">
          <span className="brand-mark"><FileSearch size={22} strokeWidth={2.4}/></span>
          <span className="brand-copy"><strong>telusur<span>.</span></strong><small>PENCARI SUMBER BERITA</small></span>
        </a>
        <nav className="nav-links">
          <a href="#cara-kerja">Cara kerja</a>
          <a href="#tentang">Tentang</a>
        </nav>
        <div className={`api-status ${health}`}>
          <span className="status-dot" />
          {health === 'online' ? 'Sistem aktif' : health === 'offline' ? 'Backend offline' : 'Memeriksa sistem'}
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-kicker"><Sparkles size={14}/> TELUSURI INFORMASI DENGAN LEBIH CERDAS</div>
          <h1>Temukan jejak sumber<br/><span>di balik sebuah berita.</span></h1>
          <p>Unggah gambar atau tangkapan layar berita. Telusur mengekstrak teks, mencari artikel terkait, lalu mengurutkan kandidat berdasarkan kemiripan teks.</p>
          <div className="hero-points">
            <span><Check size={15}/> Ekstraksi teks OCR</span>
            <span><Check size={15}/> Pencarian artikel</span>
            <span><Check size={15}/> Skor kemiripan</span>
          </div>
        </section>

        <section className="workspace" aria-label="Pencarian sumber berita">
          <div className="section-heading">
            <div>
              <span className="eyebrow">MULAI PENELUSURAN</span>
              <h2>Masukkan gambar berita</h2>
            </div>
            <span className="step-label"><span>01</span> Unggah gambar</span>
          </div>

          <div
            className={`upload-zone ${dragging ? 'dragging' : ''} ${file ? 'has-file' : ''}`}
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={e => { e.preventDefault(); setDragging(false); validateAndSet(e.dataTransfer.files?.[0]); }}
          >
            {!file ? (
              <>
                <div className="upload-icon"><UploadCloud size={29}/></div>
                <h3>Tarik gambar ke area ini</h3>
                <p>atau pilih file dari perangkat kamu</p>
                <button className="btn btn-outline" onClick={() => inputRef.current?.click()}><ImagePlus size={17}/> Pilih gambar</button>
                <div className="file-rules"><span>JPG, PNG, WEBP</span><i/> Maksimal 8 MB</div>
              </>
            ) : (
              <div className="preview-layout">
                <div className="preview-image-wrap"><img src={preview} alt="Pratinjau gambar yang diunggah"/></div>
                <div className="preview-meta">
                  <span className="file-tag"><FileImage size={14}/> GAMBAR SIAP DIPROSES</span>
                  <h3>{file.name}</h3>
                  <p>{(file.size / 1024 / 1024).toFixed(2)} MB · {file.type.split('/')[1].toUpperCase()}</p>
                  <div className="preview-actions">
                    <button className="btn btn-outline btn-small" onClick={() => inputRef.current?.click()}>Ganti gambar</button>
                    <button className="icon-btn" aria-label="Hapus gambar" onClick={reset}><X size={18}/></button>
                  </div>
                </div>
              </div>
            )}
            <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => validateAndSet(e.target.files?.[0])}/>
          </div>

          {error && <div className="alert alert-error" role="alert"><CircleAlert size={19}/><span>{error}</span><button onClick={() => setError('')} aria-label="Tutup pesan"><X size={16}/></button></div>}

          <div className="search-controls">
            <div className="privacy-note"><ShieldCheck size={17}/><span>Gambar diproses oleh backend lokal kamu.</span></div>
            <button className="btn btn-primary" onClick={runSearch} disabled={!file || loading}>
              {loading ? <><LoaderCircle className="spin" size={18}/> Sedang menelusuri...</> : <>Telusuri sumber <ArrowRight size={18}/></>}
            </button>
          </div>

          {loading && (
            <div className="loading-panel" role="status">
              <div className="loading-orb"><LoaderCircle className="spin" size={25}/></div>
              <div className="loading-copy"><strong>Sedang menelusuri gambar kamu</strong><p>Proses OCR, ekstraksi kata kunci, pencarian artikel, dan pemeringkatan teks dapat membutuhkan waktu.</p>
                <div className="progress-steps"><span className="done"><Check size={13}/> Validasi gambar</span><span className="current"><LoaderCircle size={13}/> OCR & penelusuran</span><span>Perbandingan teks</span></div>
              </div>
            </div>
          )}
        </section>

        {result && (
          <section className="results-section" aria-live="polite">
            <div className="results-title-row">
              <div><span className="eyebrow">HASIL ANALISIS</span><h2>Ringkasan penelusuran</h2></div>
              <button className="btn btn-outline btn-small" onClick={reset}><RotateCcw size={15}/> Penelusuran baru</button>
            </div>
            <div className="summary-grid">
              <div className="summary-card"><span className="summary-icon"><FileImage size={18}/></span><div><small>Teks OCR ditemukan</small><strong>{result.ocr_text ? `${result.ocr_text.length} karakter` : 'Belum ditemukan'}</strong></div></div>
              <div className="summary-card"><span className="summary-icon"><Sparkles size={18}/></span><div><small>Kata kunci</small><strong>{result.keywords?.length || 0} kata</strong></div></div>
              <div className="summary-card"><span className="summary-icon"><Newspaper size={18}/></span><div><small>Kandidat artikel</small><strong>{candidates.length} artikel</strong></div></div>
            </div>
            <div className="result-tabs">
              <button className={activeTab === 'results' ? 'active' : ''} onClick={() => setActiveTab('results')}><Newspaper size={16}/> Kandidat sumber <span>{candidates.length}</span></button>
              <button className={activeTab === 'ocr' ? 'active' : ''} onClick={() => setActiveTab('ocr')}><FileImage size={16}/> Teks OCR</button>
              <button className={activeTab === 'keywords' ? 'active' : ''} onClick={() => setActiveTab('keywords')}><Sparkles size={16}/> Kata kunci</button>
            </div>
            {activeTab === 'results' && (
              candidates.length ? <div className="candidate-list">{candidates.map((item, i) => (
                <article className="candidate-card" key={item.url || i}>
                  <div className="rank-number">{String(i + 1).padStart(2, '0')}</div>
                  <div className="candidate-main">
                    <div className="candidate-meta"><span className="source-chip"><Globe2 size={13}/>{item.domain || 'Situs berita'}</span><span className="candidate-status">{item.content_extracted ? 'Isi artikel dianalisis' : 'Judul/deskripsi dianalisis'}</span></div>
                    <h3><a href={item.url} target="_blank" rel="noreferrer">{item.title || 'Artikel tanpa judul'} <ArrowRight size={15}/></a></h3>
                    <p>{item.snippet || 'Tidak ada ringkasan yang tersedia dari sumber.'}</p>
                    <a className="source-link" href={item.url} target="_blank" rel="noreferrer">{item.url}<ChevronRight size={14}/></a>
                  </div>
                  <div className="score-box"><strong>{Math.round((item.similarity || 0) * 100)}<small>%</small></strong><span>Kemiripan</span><div className="score-track"><i style={{width: `${Math.max(0, Math.min(100, (item.similarity || 0) * 100))}%`}}/></div></div>
                </article>
              ))}</div> : <div className="empty-state"><div className="empty-icon"><Search size={24}/></div><h3>Belum ada kandidat yang cocok</h3><p>{result.message || 'Teks OCR berhasil diproses, tetapi belum ditemukan artikel kandidat yang dapat dibandingkan. Coba gambar dengan teks lebih jelas atau ulangi saat koneksi internet stabil.'}</p><button className="btn btn-outline btn-small" onClick={() => setActiveTab('ocr')}>Lihat teks hasil OCR</button></div>
            )}
            {activeTab === 'ocr' && <div className="text-panel"><div className="text-panel-head"><h3>Teks yang diekstrak dari gambar</h3><span>{result.ocr_text?.length || 0} karakter</span></div><p className="ocr-content">{result.ocr_text || 'Tidak ada teks yang berhasil diekstrak. Coba gambar yang lebih tajam, tidak miring, dan memiliki kontras yang baik.'}</p>{result.ocr_confidence != null && <div className="confidence-note"><Info size={15}/> Rata-rata confidence OCR: {(result.ocr_confidence * 100).toFixed(1)}%. Nilai ini menunjukkan confidence pengenalan teks, bukan akurasi sumber berita.</div>}</div>}
            {activeTab === 'keywords' && <div className="text-panel"><div className="text-panel-head"><h3>Kata kunci TF-IDF</h3><span>{result.keywords?.length || 0} kata</span></div>{result.keywords?.length ? <div className="keyword-list">{result.keywords.map(k => <span key={k.term} className="keyword-chip">{k.term}<small>{Number(k.score).toFixed(3)}</small></span>)}</div> : <p className="muted">Belum ada kata kunci yang dapat ditampilkan.</p>}<p className="method-note">TF-IDF membantu memberi bobot pada istilah yang informatif dalam teks. Skor cosine similarity menunjukkan kemiripan teks, bukan kepastian bahwa sumber tersebut asli atau beritanya benar.</p></div>}
            <div className="results-disclaimer"><Info size={16}/><p><strong>Perlu verifikasi:</strong> kandidat diurutkan berdasarkan kemiripan teks yang berhasil diambil. Periksa isi dan tanggal publikasi pada situs sumber; skor tertinggi bukan bukti bahwa halaman tersebut merupakan sumber asli.</p></div>
          </section>
        )}

        {!result && !loading && (
          <section className="how-section" id="cara-kerja">
            <div className="section-heading"><div><span className="eyebrow">ALUR PEMROSESAN</span><h2>Dari gambar menjadi petunjuk sumber</h2></div></div>
            <div className="steps-grid">
              <div className="step-card"><span className="step-icon"><FileImage size={21}/></span><span className="step-count">LANGKAH 01</span><h3>Ekstraksi teks</h3><p>RapidOCR mengenali teks pada gambar yang kamu unggah.</p></div>
              <div className="step-card"><span className="step-icon"><Sparkles size={21}/></span><span className="step-count">LANGKAH 02</span><h3>Ekstraksi kata kunci</h3><p>Preprocessing dan TF-IDF membantu memilih istilah penting untuk penelusuran.</p></div>
              <div className="step-card"><span className="step-icon"><Globe2 size={21}/></span><span className="step-count">LANGKAH 03</span><h3>Penelusuran artikel</h3><p>Sistem mencari kandidat artikel yang berpotensi berkaitan dengan teks.</p></div>
              <div className="step-card"><span className="step-icon"><BadgeCheck size={21}/></span><span className="step-count">LANGKAH 04</span><h3>Pemeringkatan</h3><p>Cosine Similarity mengurutkan kandidat berdasarkan kemiripan teks.</p></div>
            </div>
          </section>
        )}

        <section className="notice-strip" id="tentang"><span className="notice-icon"><BookOpen size={19}/></span><div><strong>Alat bantu penelusuran, bukan penentu kebenaran</strong><p>Telusur membantu menemukan kandidat sumber. Selalu verifikasi konteks, tanggal, dan isi berita dari situs yang tercantum.</p></div></section>
      </main>
      <footer><a className="footer-brand" href="#"><FileSearch size={17}/> telusur<span>.</span></a><span>Prototype penelitian · Pencari Sumber Berita</span><span className="footer-version">v1.0.0</span></footer>
    </div>
  );
}

export default App;
